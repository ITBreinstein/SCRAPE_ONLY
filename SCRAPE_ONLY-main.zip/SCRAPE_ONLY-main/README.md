# SCRAPE_ONLY
Deze tool scraped automatisch elke nacht vacatures van verschillende platformen, en matcht de best passende vacatures bij een CV dat je upload.
Link naar tool: https://cv-v2-app-673359121713.europe-west4.run.app
